/*
 * Date: 2012-03-19
 * Author: leike@informatik.uni-freiburg.de
 *
 * The loop is equivalent to false,
 * f(x) = 0 is a ranking function.
 */
typedef enum {false, true} bool;

extern int __VERIFIER_nondet_int(void);

int main()
{
	while (false) {
	}
	return 0;
}
